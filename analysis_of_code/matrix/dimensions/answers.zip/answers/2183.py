for t in range(int(input())):
    N = int(input())
    s = (N-1)*N
    print((s+1 + 2*N + s)*N)
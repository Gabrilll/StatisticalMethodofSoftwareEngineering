#!/usr/bin/python
# -*- coding: UTF-8 -*-s=input()
s=eval(input())
s.sort()
print(s)